import random
import unittest

from analyze_info_activity import analyze_events, activity
from feldmarschall import Position, random_setup


class ActivityTests(unittest.TestCase):
    def position(self, pieces):
        position = Position()
        for sq, army, rank, known in pieces:
            position.cells[sq] = [army, rank, False, known]
        return position

    def test_terminal_disclosure_precedes_casualty_classification(self):
        pos = self.position([(34, 0, 8, False), (35, 1, 4, False)])
        result = analyze_events(pos, [(34, 35)], 0)['weak']
        self.assertEqual(result['casualties'], 1)
        self.assertEqual(result['zero_disclosure_casualties'], 0)
        self.assertEqual(result['new_enemy_disclosures'], 1)
        self.assertEqual(result['surviving_target_disclosures'], 1)
        self.assertIsNotNone(pos.cells[34])  # Input unchanged.

    def test_known_futile_loss_and_unknown_exchange(self):
        pos = self.position([(34, 0, 6, False), (35, 1, 4, True)])
        result = analyze_events(pos, [(34, 35)], 0)['weak']
        self.assertEqual(result['zero_disclosure_casualties'], 1)
        self.assertEqual(result['known_enemy_terminal_deaths'], 1)
        self.assertEqual(result['known_losing_attack_deaths'], 1)
        pos = self.position([(34, 0, 6, False), (35, 1, 6, False)])
        result = analyze_events(pos, [(34, 35)], 0)['weak']
        self.assertEqual(result['casualties'], 1)
        self.assertEqual(result['new_enemy_disclosures'], 1)
        self.assertEqual(result['surviving_target_disclosures'], 0)

    def test_prior_personal_disclosure_follows_physical_identity(self):
        pos = self.position([(34, 0, 5, False), (35, 1, 8, False),
                             (36, 1, 4, True), (99, 1, 8, False)])
        result = analyze_events(pos, [(34, 35), (99, 98), (35, 36)], 0)
        self.assertEqual(result['weak']['casualties'], 1)
        self.assertEqual(result['weak']['zero_disclosure_casualties'], 0)
        self.assertEqual(result['weak']['known_losing_attack_deaths'], 1)
        self.assertEqual(result['by_rank']['5']['new_enemy_disclosures'], 1)

    def test_unknown_attacker_disclosure_counts_for_weak_defender(self):
        pos = self.position([(34, 0, 8, False), (36, 1, 4, False)])
        result = analyze_events(pos, [(34, 35), (36, 35)], 0)['weak']
        self.assertEqual(result['casualties'], 1)
        self.assertEqual(result['zero_disclosure_casualties'], 0)
        result = analyze_events(self.position([(34, 0, 4, False), (35, 1, 8, False)]),
                                [(34, 35)], 1)['weak']
        self.assertEqual(result['casualties'], 1)
        self.assertEqual(result['zero_disclosure_casualties'], 0)
        self.assertEqual(result['new_enemy_disclosures'], 1)
        self.assertEqual(result['concealed_enemy_attacks'], 0)

    def test_long_scout_is_already_disclosed_when_captured(self):
        pos = self.position([(30, 0, 8, False), (35, 1, 6, False)])
        result = analyze_events(pos, [(30, 34), (35, 34)], 1)['weak']
        self.assertEqual(result['new_enemy_disclosures'], 0)
        self.assertEqual(result['unit_appearances'], 1)

    def test_miner_separate_and_terminal_flag(self):
        pos = self.position([(34, 0, 7, False), (35, 1, 4, True)])
        result = analyze_events(pos, [(34, 35)], 0)
        self.assertEqual(result['miners_lost'], 1)
        self.assertEqual(result['weak']['casualties'], 0)
        pos = self.position([(34, 0, 8, False), (35, 1, 11, False)])
        result = analyze_events(pos, [(34, 35)], 0)['weak']
        self.assertEqual(result['new_enemy_disclosures'], 1)
        with self.assertRaises(ValueError):
            analyze_events(pos, [(34, 35), (35, 36)], 0)

    def test_illegal_trace_rejected(self):
        with self.assertRaises(ValueError):
            analyze_events(self.position([(34, 0, 6, False)]), [(34, 36)], 0)

    def test_game_cohort_denominators_and_policy_resolution(self):
        rng = random.Random(17311)
        game = dict(red='candidate', blue='control',
                    red_setup=random_setup(rng), blue_setup=random_setup(rng),
                    moves=[], result='error', id=1, pair_id=2, seed=17311,
                    family='fortified')
        result = activity(game, 'candidate')
        self.assertEqual(result['appearances'], 1)
        self.assertEqual(result['scored_games'], 0)
        self.assertEqual(result['error_prefixes'], 1)
        self.assertEqual(result['side'], 0)
        self.assertGreater(result['weak']['unit_appearances'], 0)
        game['result'] = 'draw'
        result = activity(game, 'control')
        self.assertEqual(result['side'], 1)
        self.assertEqual(result['scored_games'], 1)
        self.assertEqual(result['error_prefixes'], 0)
        with self.assertRaises(ValueError):
            activity(game, 'absent')


if __name__ == '__main__':
    unittest.main()
