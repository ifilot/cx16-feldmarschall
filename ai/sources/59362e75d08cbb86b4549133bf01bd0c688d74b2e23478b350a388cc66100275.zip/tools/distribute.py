"""Create a reproducible binary distribution containing only runtime files.

Usage:
  python3 tools/distribute.py          (or: make dist)

Writes build/dist/FELDMARSCHALL/ and build/dist/FELDMARSCHALL.ZIP. The runtime files
are the game itself, a copy named AUTOBOOT.X16 that the X16 starts on
power-up, every file loaded into VRAM, and the banked code/music/effects
declared in src/ui/sound.c. The test
programs (BRIDGE.PRG), saved deployments (DEPLOY.DAT), the saved game
(GAME.DAT) and appearance preferences (COLORS.DAT) stay out. Entries carry a fixed date, so the same build gives the same ZIP.
"""
import hashlib
import re
import shutil
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile, ZipInfo

ROOT = Path(__file__).resolve().parents[1]
NAME = 'FELDMARSCHALL'


def runtime_files():
    video = (ROOT / 'src/ui/video.c').read_text()
    resources = re.findall(r'load_vram\("([A-Z0-9]+\.[A-Z0-9]+)"', video)
    sound = (ROOT / 'src/ui/sound.c').read_text()
    resources += re.findall(r'"([A-Z0-9]+\.(?:BIN|ZSM))"', sound)
    assert resources, 'no load_vram calls found in src/ui/video.c'
    return ['FELDMARS.PRG'] + list(dict.fromkeys(resources))


README = '''CX16 Feldmarschall

A game of hidden armies for the Commander X16, at 640x480 with selectable
field and army color palettes.

Keep all files in this directory together on your X16 SD card. Copy them
to the root of the card to boot the game automatically: AUTOBOOT.X16 is a
copy of FELDMARS.PRG and starts the game on power-up. Otherwise load
FELDMARS.PRG and run it.

Emulator: x16emu -prg FELDMARS.PRG -run

Press Enter at the splash screen to open the menu.
Choose 1 SETUPS to create, load or save army arrangements; Back
returns to the menu. Choose 2 SKIRMISH to deploy your
game rules, then deploy your army before a match. Start is enabled when all 40 pieces are on the board.
Choose 3 LOAD GAME to resume the game saved in GAME.DAT.
Choose DEMO to watch two computer armies battle with deployments selected
for the current difficulty and rules. Menu pauses and offers separate music/effects toggles; demos cannot save.
New game at the result starts another demo.
Choose 4 OPTIONS to select field styles, army colors and rank numbers
(classic: 1 = Marshal, S = Spy; modern: 1 = Spy, 10 = Marshal).
Choose 5 ABOUT for the author, repository, version, and compilation date.
Click for a live preview. Tab switches groups; Up/Down or numbers select.
Enter, Escape or Back saves the choices in COLORS.DAT and opens the menu.
The game is played with the mouse. Deploy your army by dragging pieces
from the tray onto your four home rows, or load one of ten classic
deployments; then play against the computer. Escape opens the game menu:
resume, save the game to GAME.DAT, or quit to the main menu.
Deployments you save go into DEPLOY.DAT, which the game creates here.

FELDMARS.PRG is the game; the .BIN files hold its graphics and palette.

Source, license (GPL-3.0-or-later) and credits:
https://github.com/ifilot/cx16-feldmarschall
'''


def main():
    destination = ROOT / 'build/dist' / NAME
    if destination.exists():
        shutil.rmtree(destination)
    destination.mkdir(parents=True)

    files = runtime_files()
    for name in files:
        base, extension = name.split('.')
        assert 1 <= len(base) <= 8 and 1 <= len(extension) <= 3, f'{name} is not an 8.3 name'
        source = ROOT / 'src' / name
        assert source.exists(), f'{source} is missing: run make first'
        shutil.copyfile(source, destination / name)
    shutil.copyfile(ROOT / 'src/FELDMARS.PRG', destination / 'AUTOBOOT.X16')
    (destination / 'README.TXT').write_text(README)
    shutil.copyfile(ROOT / 'LICENSE', destination / 'LICENSE.TXT')

    names = sorted(p.name for p in destination.iterdir())
    hashes = {name: hashlib.sha256((destination / name).read_bytes()).hexdigest() for name in names}
    (destination / 'HASHES.TXT').write_text(''.join(f'{hashes[n]}  {n}\n' for n in names))

    archive = destination.parent / f'{NAME}.ZIP'
    with ZipFile(archive, 'w', compression=ZIP_DEFLATED) as output:
        for path in sorted(destination.iterdir()):
            entry = ZipInfo(f'{NAME}/{path.name}', date_time=(1980, 1, 1, 0, 0, 0))
            entry.compress_type = ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            output.writestr(entry, path.read_bytes())
    with ZipFile(archive) as packaged:
        assert packaged.testzip() is None, 'the ZIP failed its CRC check'
        for name, digest in hashes.items():
            assert hashlib.sha256(packaged.read(f'{NAME}/{name}')).hexdigest() == digest, name
    contents = list(destination.iterdir())
    print(f'Distribution: {archive.relative_to(ROOT)} ({archive.stat().st_size} bytes; '
          f'{len(contents)} files, {sum(p.stat().st_size for p in contents)} bytes unpacked)')


if __name__ == '__main__':
    main()
