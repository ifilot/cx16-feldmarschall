"""Geometric/rank invariants for the retrospective interceptor audit."""
import unittest

from analyze_campaign_flag_guard import clone, coverage, public_position
from feldmarschall import Position


def fixture(intruder_rank=1, guard_rank=0):
    position = Position()
    position.cells[95] = [0, 11, False, False]
    position.cells[75] = [1, intruder_rank, True, True]
    position.cells[84] = [0, guard_rank, True, False]
    return position


class GuardCoverageTests(unittest.TestCase):
    def test_guard_preserves_next_turn_interception(self):
        position = fixture()
        self.assertTrue(coverage(position, 0, 75)['covered'])
        self.assertEqual(coverage(position, 0, 75)['guards'], [84])
        position.move(84, 83)
        self.assertFalse(coverage(position, 0, 75)['covered'])
        position.move(83, 84)
        self.assertTrue(coverage(position, 0, 75)['covered'])

    def test_spy_interception_differs_from_static_blocking(self):
        for attacker, guard in ((0, 9), (9, 0)):
            position = fixture(attacker, guard)
            self.assertTrue(coverage(position, 0, 75)['covered'])
            position.move(84, 85)
            self.assertFalse(coverage(position, 0, 75)['covered'])

    def test_weaker_guard_cannot_promise_interception(self):
        position = fixture(1, 7)
        self.assertFalse(coverage(position, 0, 75)['covered'])

    def test_immediate_scout_ray_and_friendly_blocker(self):
        position = Position()
        position.cells[95] = [0, 11, False, False]
        position.cells[5] = [1, 8, True, True]
        self.assertTrue(coverage(position, 0, 5)['immediate'])
        position.cells[55] = [0, 0, True, True]
        self.assertFalse(coverage(position, 0, 5)['immediate'])
        self.assertTrue(coverage(position, 0, 5)['covered'])

    def test_other_concealed_ranks_are_masked_and_no_mutation(self):
        position = fixture()
        position.cells[1] = [1, 0, False, False]
        before = clone(position)
        a = coverage(public_position(position, 0), 0, 75)
        position.cells[1][1] = 9
        b = coverage(public_position(position, 0), 0, 75)
        self.assertEqual(a, b)
        self.assertEqual(before.cells[75], position.cells[75])
        self.assertEqual(before.shuttle, position.shuttle)

    def test_public_two_squares_restriction_is_respected(self):
        position = fixture()
        position.shuttle[0] = (85, 84, 5)
        self.assertFalse(coverage(position, 0, 75)['covered'])
        # A different own move resets that army's restriction before its next
        # interception opportunity, which the branch must also represent.
        position.cells[90] = [0, 8, True, False]
        position.move(90, 80)
        self.assertTrue(coverage(position, 0, 75)['covered'])
        position = fixture()
        position.shuttle[1] = (85, 75, 5)
        self.assertTrue(coverage(position, 0, 75)['covered'])
        self.assertEqual(coverage(position, 0, 75)['approaches'], [])

    def test_rotation_and_colour_symmetry(self):
        position = fixture()
        rotated = Position()
        rotated.cells = [None if c is None else [1-c[0], *c[1:]] for c in reversed(position.cells)]
        self.assertTrue(coverage(rotated, 1, 24)['covered'])
        self.assertEqual(coverage(rotated, 1, 24)['guards'], [15])


if __name__ == '__main__':
    unittest.main()
