"""Public-event activation audit on a named, previously screened cohort only."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import time

from campaign_template_beliefs import TemplateMixtureBeliefs
from new_campaign_information import MissedCaptureBeliefs
from test_information_parent_parity import public_events
from tournament_store import Tournament,replay


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('tournament',type=Path)
    parser.add_argument('--games',type=int,default=100)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    if 'screen' not in str(args.tournament) or 'validation' in str(args.tournament):
        raise ValueError('activation audit requires an explicitly screened, non-validation cohort')
    totals=Counter();changed=[];elapsed=0.
    with Tournament(args.tournament) as tour:
        rows=[row for row in tour.games() if row['result']!='error'][:args.games]
        for row in rows:
            game=tour.game(row['id']);states,_=replay(game)
            events=public_events(game,states)
            for army in (0,1):
                model=MissedCaptureBeliefs()
                model.observe(['new',('red','blue')[army]])
                model.observe(['setup',game[('red_setup','blue_setup')[army]]])
                seen=False;different=False
                for event in events:
                    started=time.perf_counter();model.observe(event.split())
                    weights,_=model.posterior();elapsed+=time.perf_counter()-started
                    baseline,_=TemplateMixtureBeliefs.posterior(model)
                    totals['public_events']+=1
                    if model.miss:
                        totals['active_events']+=1;seen=True
                    delta=max(abs(a-b) for a,b in zip(weights,baseline))
                    if delta>1e-12:
                        different=True;totals['changed_posterior_events']+=1
                        if len(changed)<20:changed.append(dict(game=game['id'],army=army,ply=model.plies,
                            maximum_weight_delta=delta,observation=model.miss.copy()))
                totals['side_histories']+=1;totals['histories_with_evidence']+=seen
                totals['histories_with_changed_posterior']+=different
    doc=dict(kind='public-screen-activation-only',tournament=str(args.tournament),
        source_sha256=hashlib.sha256(args.tournament.read_bytes()).hexdigest(),
        selection='first complete game IDs, both armies; fixed before inspection',games=len(rows),
        counts=dict(totals),examples=changed,host_observe_and_posterior_seconds=elapsed,
        seconds_per_public_event=elapsed/max(1,totals['public_events']),
        limitation='No move choices or strength estimate. Events disclose battle ranks only; each model receives its own setup. Old screening histories are development evidence only.')
    args.out.write_text(json.dumps(doc,indent=2)+'\n');print(json.dumps(doc))


if __name__=='__main__':main()
