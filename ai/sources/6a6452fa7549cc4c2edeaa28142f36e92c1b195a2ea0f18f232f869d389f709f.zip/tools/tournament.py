"""Run named Classic AIs in paired tournaments; inspect and verify .fmtour files."""
import argparse
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import shlex
import shutil
import sys
import tempfile

from ai_registry import ROOT, build_policy, catalog
from arena import deployments
from feldmarschall import new_rng
from tournament_store import Tournament, verify

FAMILIES = ('fortified', 'uniform', 'unguarded', 'forward', 'decoy', 'presets', 'broad-mixed')


def initialize_worker(directory):
    # Pin referee code for the entire tournament, even if the checkout changes.
    for module in ('arena', 'feldmarschall'):
        sys.modules.pop(module, None)
    sys.path.insert(0, directory)


def play_job(job):
    from arena import play
    return play(job)


def run(first, second, out, rounds=10, seed=1, jobs=1, families=FAMILIES, max_plies=1000):
    if first == second:
        raise ValueError('Choose two different AI versions')
    if rounds < 1 or jobs < 1 or max_plies < 1 or not families or any(f not in FAMILIES for f in families):
        raise ValueError('Positive rounds, workers and ply limit, and known layout families required')
    if Path(out).exists():
        raise FileExistsError(f'Tournament already exists: {out}')
    built = [build_policy(identity) for identity in (first, second)]
    participants = [receipt for _, receipt in built]
    plan = dict(created_utc=datetime.now(timezone.utc).isoformat(), participants=participants,
                seed=seed, rounds=rounds, families=list(families), max_plies=max_plies,
                planned_games=2 * rounds * len(families),
                comparison='move policies with common referee-generated deployments; swapped sides',
                score='win=1, draw=0.5, loss=0; paired games share deployments and seed')
    with Tournament(out, create=True, metadata=plan) as tournament, tempfile.TemporaryDirectory(prefix='fmtour-') as temp:
        working = Path(temp)
        commands = {}
        for (executable, receipt), identity in zip(built, (first, second)):
            bundle = working / identity
            bundle.mkdir()
            for name in receipt['runtime_sha256']:
                shutil.copy2(executable.parent / name, bundle / name)
                tournament.artifact(identity + '/' + name, (bundle / name).read_bytes())
            frozen = bundle / executable.name
            commands[identity] = shlex.join([str(frozen), '--difficulty', receipt['policy']['difficulty']])
            tournament.artifact(receipt['policy']['archive'], (ROOT / receipt['policy']['archive']).read_bytes())
        referee = working / 'referee'
        referee.mkdir()
        for name in ('arena.py', 'feldmarschall.py'):
            data = (ROOT / 'tools' / name).read_bytes()
            (referee / name).write_bytes(data)
            tournament.artifact('referee/' + name, data)
        queue, descriptions = [], []
        rng = new_rng(seed)
        for family in families:
            for _ in range(rounds):
                setups = (deployments(family, rng), deployments(family, rng))
                move_seed = rng.randrange(1, 60000)
                pair_id = len(descriptions) // 2 + 1
                for names in ((first, second), (second, first)):
                    queue.append((names, tuple(commands[n] for n in names), setups, move_seed, max_plies, True))
                    descriptions.append((pair_id, family, setups))
        try:
            with ProcessPoolExecutor(max_workers=jobs, initializer=initialize_worker, initargs=(str(referee),)) as pool:
                for game, (pair_id, family, setups) in zip(pool.map(play_job, queue), descriptions):
                    if game['reason'].startswith('illegal'):
                        raise ValueError(f'AI produced an {game["reason"]}')
                    tournament.add_game(game, pair_id, family, setups)
                    print(json.dumps(dict(event='progress', completed=len(tournament.games()), total=len(queue))), flush=True)
            tournament.set_metadata(dict(status='complete', finished_utc=datetime.now(timezone.utc).isoformat()))
        except BaseException as error:
            tournament.set_metadata(dict(status='interrupted' if isinstance(error, KeyboardInterrupt) else 'failed', error=str(error)))
            raise
        return tournament.summary()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_subparsers(dest='action', required=True)
    actions.add_parser('list')
    play = actions.add_parser('run')
    play.add_argument('first')
    play.add_argument('second')
    play.add_argument('--out', type=Path, required=True)
    play.add_argument('--rounds', type=int, default=10, help='paired rounds per layout family')
    play.add_argument('--seed', type=int, default=1)
    play.add_argument('--jobs', type=int, default=min(4, os.cpu_count() or 1))
    play.add_argument('--families', nargs='+', choices=FAMILIES, default=FAMILIES)
    play.add_argument('--max-plies', type=int, default=1000)
    actions.add_parser('show').add_argument('path', type=Path)
    actions.add_parser('verify').add_argument('path', type=Path)
    args = parser.parse_args()
    try:
        if args.action == 'list':
            for policy in catalog():
                print(f'{policy["id"]:38s} {policy["name"]} [{policy["status"]}]')
        elif args.action == 'run':
            print(json.dumps(run(args.first, args.second, args.out, args.rounds, args.seed,
                                 args.jobs, args.families, args.max_plies), indent=2))
        elif args.action == 'verify':
            print(json.dumps(verify(args.path), indent=2))
        else:
            with Tournament(args.path) as tournament:
                print(json.dumps(tournament.summary(), indent=2))
    except (ValueError, OSError) as error:
        parser.exit(1, f'{error}\n')


if __name__ == '__main__':
    main()
