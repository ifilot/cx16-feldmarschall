"""Historical public-root diagnostic for fixed versus capture-extended horizons.

No campaign validation games or concealed labels select roots or parameters.
All three variants see identical public prefixes and sampled-world RNG streams.
The depth-eight reference is another heuristic search, not a best-move oracle.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import zipfile

from ai_registry import ROOT, build_policy, get_policy
from teacher_bot import TeacherBot
from test_information_parent_parity import public_events
from tournament_store import Tournament, replay


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def summarize(roots):
    result = dict(roots=len(roots), families=dict(Counter(r['family'] for r in roots)), comparisons={})
    for left, right in (('fixed4', 'quiescent4'), ('fixed4', 'fixed8'), ('quiescent4', 'fixed8')):
        changed = 0
        delta, shifts, nodes = [], [], []
        for root in roots:
            a, b = root['reports'][left], root['reports'][right]
            changed += a['selected'] != b['selected']
            values = {tuple(v['move']): v['value'] for v in b['values']}
            # Apparent loss according to the second search only, not truth.
            delta.append(values[tuple(b['selected'])] - values[tuple(a['selected'])])
            av = {tuple(v['move']): v['correction'] for v in a['values']}
            shifts.extend(abs(v['correction']-av[tuple(v['move'])]) for v in b['values'])
            nodes.append(b['nodes'] / a['nodes'] if a['nodes'] else 1)
        result['comparisons'][left+'--'+right] = dict(
            changed_decisions=changed, disagreement_rate=changed/len(roots),
            mean_second_search_score_shortfall=sum(delta)/len(delta),
            mean_absolute_action_correction_shift=sum(shifts)/len(shifts),
            mean_node_ratio=sum(nodes)/len(nodes))
    result['mean_nodes'] = {mode: sum(r['reports'][mode]['nodes'] for r in roots)/len(roots)
                            for mode in ('fixed4', 'quiescent4', 'fixed8')}
    return result


def run(source, root_path, destination, decisions=140):
    destination.mkdir(parents=True, exist_ok=True)
    output = destination/'quiescence-mechanism.json'
    if output.exists():
        raise ValueError('preserve completed research output; choose a new destination')
    historical = json.loads(root_path.read_text())
    # Interleave through the already frozen historical development cohort.
    stride = max(1, len(historical['roots']) // decisions)
    selected_roots = historical['roots'][::stride][:decisions]
    if len(selected_roots) != decisions:
        raise ValueError('insufficient historical development roots')
    selections = {}
    for row in selected_roots:
        selections.setdefault((row['game'], row['army']), set()).add(row['ply'])
    baseline = get_policy('teacher-context-v1-normal')
    executable, receipt = build_policy(baseline['id'])
    roots = []
    with tempfile.TemporaryDirectory(prefix='feld-horizon-mechanism-') as temporary:
        temporary = Path(temporary)
        with zipfile.ZipFile(ROOT/baseline['archive']) as archive:
            archive.extractall(temporary/'source')
        # Freeze all native core semantics to the old baseline. Only the owned
        # compile-guarded rollout source comes from the current research tree.
        (temporary/'source/src/native/teacher_rollout.c').write_bytes(
            (ROOT/'src/native/teacher_rollout.c').read_bytes())
        programs = {}
        for name, extra in (('base', []), ('quiescent', ['AI_ROLLOUT_QUIESCENCE'])):
            program = temporary/name
            command = ['gcc', '-O2', '-std=c99', '-Wno-unknown-pragmas', '-Isrc/core', '-o', str(program)]
            command += ['-D'+define for define in baseline['teacher_defines']+extra]
            command += baseline['teacher_sources']
            subprocess.run(command, cwd=temporary/'source', check=True, capture_output=True)
            programs[name] = program
        runtime_hashes = {name: digest(program) for name, program in programs.items()}
        bots = {mode: TeacherBot(executable.parent/'observer', programs[program], samples=8,
                                depth=depth, blend='correction', strategic=True, context=True)
                for mode, program, depth in (('fixed4', 'base', 4), ('quiescent4', 'quiescent', 4),
                                            ('fixed8', 'base', 8))}
        try:
            with Tournament(source) as tournament:
                for game_id, army in sorted(selections):
                    game = tournament.game(game_id)
                    states, _ = replay(game)
                    events = public_events(game, states)
                    targets = selections[(game_id, army)]
                    seed = game['seed']*2+army+1
                    for bot in bots.values():
                        bot.rng.seed(seed)
                        for command in ('new '+('red','blue')[army], 'rules 0', 'difficulty normal',
                                        'seed '+str(seed), 'setup '+game[('red_setup','blue_setup')[army]]):
                            bot.observer.send(command)
                    for ply, event in enumerate(events[:max(targets)+1]):
                        if ply % 2 == army:
                            if ply in targets:
                                public = [bot.observer.ask('public','public') for bot in bots.values()]
                                strategic = [bot.observer.ask('strategy','strategy') for bot in bots.values()]
                                assert len(set(public)) == len(set(strategic)) == 1
                                reports = {}
                                streams = []
                                for mode, bot in bots.items():
                                    bot.choose()
                                    reports[mode] = bot.last_report
                                    streams.append(repr(bot.rng.getstate()))
                                assert len(set(streams)) == 1, 'world RNG consumption changed'
                                roots.append(dict(game=game_id, army=army, family=game['family'],
                                                  ply=ply, public_sha256=hashlib.sha256(public[0].encode()).hexdigest(),
                                                  reports=reports))
                                print('Historical horizon root',len(roots),'/',decisions,flush=True)
                            else:
                                for bot in bots.values():
                                    bot.observer.ask('go','move')
                            for bot in bots.values():
                                bot.observer.ask('played '+' '.join(event.split()[1:3]),'playedok')
                        for bot in bots.values():
                            bot.observer.send(event)
        finally:
            for bot in bots.values():
                bot.close()
    tests = subprocess.run(['python3','-m','unittest','discover','-s','tools','-p',
                            'test_campaign_quiescence.py','-v'], cwd=ROOT, capture_output=True,
                           text=True, check=True)
    (destination/'quiescence-native-tests.log').write_text(tests.stdout+tests.stderr)
    result = dict(kind='historical-public-horizon-mechanism', strength_evidence=False,
                  input='Own setup and public history only; hypothetical armies sampled identically.',
                  source=str(source.relative_to(ROOT)), source_sha256=digest(source),
                  historical_roots_sha256=digest(root_path), native_runtime_sha256=runtime_hashes,
                  current_rollout_sha256=digest(ROOT/'src/native/teacher_rollout.c'),
                  baseline_receipt=receipt, samples=8, extension_policy_decision_cap=4,
                  native_privacy_and_capture_tests_passed=True,
                  summary=summarize(roots), roots=roots)
    output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result['summary'],indent=2),flush=True)
    return result


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,default=ROOT/'docs/ai-restrained-search-2026-10-15/development.fmtour')
    parser.add_argument('--roots',type=Path,default=ROOT/'docs/ai-restrained-search-2026-10-15/development-roots.json')
    parser.add_argument('--out',type=Path,default=ROOT/'docs/ai-honest-campaign-2026-10-15/research/horizon')
    parser.add_argument('--decisions',type=int,default=140)
    args=parser.parse_args()
    run(args.source,args.roots,args.out,args.decisions)
