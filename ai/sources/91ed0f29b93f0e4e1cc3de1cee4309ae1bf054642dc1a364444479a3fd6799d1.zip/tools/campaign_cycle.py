"""Frozen honest-AI campaign cycles: matched Classic DOS games and full replay."""
import argparse
import contextlib
import copy
import json
import time
from pathlib import Path

from ai_registry import ROOT, catalog, get_policy, register, receives_opponent_setup
from information_strategy_cycle import analyze_match, bootstrap, digest, validate_metadata
from tournament import run

BASE = ROOT / 'docs/ai-honest-campaign-2026-10-15'
FAMILIES = ['fortified', 'uniform', 'unguarded', 'forward', 'decoy', 'presets', 'broad-mixed']


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def freeze(directory):
    plan = json.loads((directory/'plan.json').read_text())
    assert not (directory/'frozen-policies.json').exists()
    write(directory/'registry-before.json', dict(policies=catalog()))
    for spec in plan['new_policies']:
        assert not receives_opponent_setup(spec)
        assert 'AI_DIAGNOSTIC_TRUTH' not in spec['defines']
        assert '--diagnostic-truth' not in spec.get('driver_args', [])
        register(spec)
    identities = list(dict.fromkeys([*plan['policies'], plan['opponent'], plan['baseline']]))
    write(directory/'frozen-policies.json', {p: get_policy(p) for p in identities})
    write(directory/'registration.json', dict(epoch=time.time(), plan_sha256=digest(directory/'plan.json')))


def evaluate(directory):
    plan = json.loads((directory/'plan.json').read_text())
    frozen = json.loads((directory/'frozen-policies.json').read_text())
    registration = json.loads((directory/'registration.json').read_text())
    assert registration['plan_sha256'] == digest(directory/'plan.json')
    before = json.loads((directory/'registry-before.json').read_text())['policies']
    assert catalog()[:len(before)] == before
    assert all(get_policy(p) == spec for p, spec in frozen.items())
    reports, pairs, signature = {}, {}, None
    for identity in plan['policies']:
        match = dict(name=identity, group='dos', policy=identity, opponent=plan['opponent'],
                     seed=plan['seed'], rounds=plan['rounds'])
        path = directory/(identity+'.fmtour')
        if not path.exists():
            print('Running', identity, flush=True)
            with path.with_suffix('.log').open('x') as log, contextlib.redirect_stdout(log):
                result = run(identity, plan['opponent'], path, rounds=plan['rounds'], seed=plan['seed'],
                             jobs=plan['jobs'], families=plan['families'], max_plies=plan['max_plies'],
                             backend=plan['backend'])
                print(json.dumps(result), flush=True)
        validate_metadata(path, match, plan, frozen)
        assert path.stat().st_mtime >= registration['epoch']
        report_path = path.with_suffix('.report.json')
        # Reanalyse from artifacts: never silently reuse stale cached statistics.
        report, complete, current = analyze_match(path, match, plan, frozen)
        if signature is None:
            signature = current
        assert current == signature, 'Unmatched armies or seeds'
        reports[identity], pairs[identity] = report, complete
        write(report_path, report)
        print('Verified', identity, report['summary']['standings'][identity], flush=True)
    comparisons = {}
    for first, second in plan['contrasts']:
        common = sorted(pairs[first].keys() & pairs[second].keys())
        comparisons[first+' minus '+second] = bootstrap([
            (pairs[first][key][0], dict(score=pairs[first][key][1]['score']-pairs[second][key][1]['score']))
            for key in common])
    result = dict(cycle=plan['cycle'], hypotheses=plan['hypotheses'],
                  standings={p:r['summary']['standings'][p] for p,r in reports.items()},
                  execution_seconds={p:r['execution_seconds'] for p,r in reports.items()},
                  comparisons=comparisons, attempts=sum(r['summary']['games'] for r in reports.values()),
                  errors=sum(r['summary']['errors'] for r in reports.values()),
                  production='Unchanged. Campaign screening evidence, not a promotion decision.',
                  verified_games=sum(r['verification']['native_replayed_all_states'] for r in reports.values()))
    write(directory/'result.json', result)
    write(directory/'manifest.json', {str(p.relative_to(directory)):digest(p)
          for p in sorted(directory.rglob('*')) if p.is_file() and p.name != 'manifest.json'})
    overview()
    return result


def overview():
    lines = ['# Honest AI campaign: cumulative DOS results', '',
             'Scores count wins plus half of draws; original DOS errors are excluded. '
             'Compare policies within their matched cycle. Screening results do not establish promotion.', '',
             '| Cycle / hypothesis | Policy | W / D / L | DOS score | Errors |',
             '|---|---|---:|---:|---:|']
    for path in sorted(BASE.glob('cycle-*/result.json')):
        result = json.loads(path.read_text())
        for policy, standing in result['standings'].items():
            # Standings preserve the canonical tournament schema.
            wins, draws, losses = (standing[k] for k in ('wins','draws','losses'))
            count = wins+draws+losses
            score = (wins+.5*draws)/count if count else 0
            lines.append(f"| {result['cycle']} | {policy} | {wins} / {draws} / {losses} | {score:.1%} | {standing.get('errors', 0)} |")
        lines += ['', '**Cycle '+str(result['cycle'])+' hypotheses:** '+
                  '; '.join(result['hypotheses']), '',
                  'Evidence: ['+path.parent.name+']('+path.parent.name+'/result.json).', '']
        for name, contrast in result['comparisons'].items():
            metric = contrast['metrics']['score']
            low, high = metric['interval_95']
            lines.append(f"- {name}: {100*metric['mean']:+.1f} percentage points; 95% paired interval [{100*low:+.1f}, {100*high:+.1f}].")
        lines.append('')
    (BASE/'OVERVIEW.md').write_text('\n'.join(lines)+'\n')


def init_sampling():
    directory = BASE/'cycle-01-sampling-budget'
    assert not directory.exists()
    directory.mkdir(parents=True)
    baseline, learned = 'teacher-context-v1-normal', 'teacher-calibrated-beliefs-v1-normal'
    new = []
    for parent, identity in ((baseline, 'teacher-context-worlds32-v1-normal'),
                             (learned, 'teacher-calibrated-worlds32-v1-normal')):
        spec = copy.deepcopy(get_policy(parent))
        for key in ('archive', 'source_sha256'):
            spec.pop(key)
        spec.update(id=identity, name=identity, status='experimental',
                    description='Honest 32-world sampling-budget ablation of '+parent,
                    model='Unchanged four-ply guarded Context Teacher; 32 independent public-compatible armies.')
        spec['driver_args'][spec['driver_args'].index('--samples')+1] = '32'
        new.append(spec)
    policies = [baseline, learned, *[p['id'] for p in new]]
    write(directory/'plan.json', dict(cycle=1, baseline=baseline, opponent='msdos-1990-v2-normal',
          policies=policies, new_policies=new, seed=2090001, rounds=20, jobs=4, max_plies=1000,
          backend='openmp', families=FAMILIES,
          hypotheses=['More public-compatible enemy armies reduce decision noise at four times rollout work.',
                      'Calibrated beliefs benefit more from 32 armies than from eight; test the model-by-budget interaction.'],
          contrasts=[[policies[2],baseline],[policies[3],learned],[learned,baseline],[policies[3],policies[2]]],
          analysis='Fixed fresh screening cohort. 20000 family-stratified swapped-pair bootstrap replicates. '
                   'Report every contrast and cost, no production promotion from these exploratory comparisons. '
                   'All public-state traces replayed independently in Python and native worker; Qt6 capture each policy.',
          honesty='No opponent setup, diagnostic observer or referee ranks enter any policy. '
                  'Learned model was frozen before this campaign; no fitting on these seeds.'))
    return directory


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['init-sampling','freeze','run','overview'])
    parser.add_argument('--directory', type=Path)
    args = parser.parse_args()
    if args.action == 'init-sampling':
        print(init_sampling())
    elif args.action == 'freeze':
        freeze(args.directory)
    elif args.action == 'run':
        evaluate(args.directory)
    else:
        overview()


if __name__ == '__main__':
    main()
