#define ENSEMBLE_TREES 8
#define ENSEMBLE_SCALE 1000
static const unsigned int ensemble_offsets[]={0,0,0,0,0,0,0,0};
static const ensemble_node_t ensemble_nodes[]={{255,0,0,0,-30000}};
