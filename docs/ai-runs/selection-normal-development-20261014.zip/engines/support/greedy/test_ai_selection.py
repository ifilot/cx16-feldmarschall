"""Check diversity constraints and selection independence from side/opponent."""
import unittest

from benchmark_ai_selection import choose_weights, layouts, selected_cases
from optimize_ai_deployments import trials


class SelectionTests(unittest.TestCase):
    def test_constrained_optimum(self):
        weights = choose_weights([1, .8, .6, .1])
        self.assertEqual(weights, (5, 4, 1, 0))
        self.assertEqual(sum(weights), 10)
        self.assertEqual(max(weights), 5)

    def test_block_selection(self):
        retained = layouts()
        policy = {'layouts': retained, 'weights': dict(zip(retained, (5, 3, 2, 0)))}
        cases = trials(61261014, 20, ['v020', 'planned', 'adaptive', 'easy', 'greedy'])
        actual, blocks = selected_cases(cases, policy, 1234)
        self.assertEqual((actual, blocks), selected_cases(cases, policy, 1234))
        self.assertEqual(len(blocks), 140)
        self.assertEqual(len(set(actual.values())), 3)
        for start in range(0, len(cases), 5):
            self.assertEqual(len({actual[i] for i in range(start, start + 5)}), 1)
        # Public opponent layout and opponent name cannot influence the draw.
        altered = [{**case, 'opponent': 'different', 'opponent_setup': 'ignored'} for case in cases]
        self.assertEqual((actual, blocks), selected_cases(altered, policy, 1234))


if __name__ == '__main__':
    unittest.main()
