#include <stdint.h>
#include <stdio.h>
#include "board.h"
#include "ai.h"
#include "setup.h"
uint8_t board[SQUARES], game_rules=0, ai_difficulty=AI_NORMAL;
static uint16_t calls;
uint16_t random_next(void) { ++calls; return 123u; }
void setup_random(uint8_t blue) { (void)blue; }
int main(int argc, char **argv) {
 uint16_t n,sum=0;uint8_t i,blue=(argc>1 && argv[1][0]=='1');
 for(n=0;n<1000u;++n) setup_ai(blue);
 for(i=0;i<100u;++i) sum+=board[i];
 printf("%u %u\n",calls,sum);
 return 0;
}
