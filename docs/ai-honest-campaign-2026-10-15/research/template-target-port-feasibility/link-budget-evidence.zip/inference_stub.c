#include <stdint.h>
#pragma code-name ("BELIEFCODE")
#pragma rodata-name ("BELIEFRODATA")
#pragma bss-name ("BELIEFBSS")
extern int16_t template_transfer[100];
/* Space reservations, not an inference implementation. */
const uint8_t template_constants[320]={0};
uint16_t posterior_q12[200];
int16_t all_rank_cache[12][100];
uint8_t inference_scratch[256];
void template_prepare_banked(void) {}
void __fastcall__ template_row_banked(uint8_t rank) {
 uint8_t i;for(i=0;i<100;i++)template_transfer[i]=all_rank_cache[rank][i];
}
