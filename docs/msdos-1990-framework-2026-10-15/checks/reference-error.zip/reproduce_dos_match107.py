import sys,json,traceback
from pathlib import Path
sys.path.insert(0,'tools')
from msdos1990 import *
from arena import deployments
from tournament import FAMILIES
from feldmarschall import new_rng,Engine,FLAG
rng=new_rng(1912001);index=0
for fam in FAMILIES:
 for rr in range(10):
  setups=[deployments(fam,rng),deployments(fam,rng)];seed=rng.randrange(1,60000)
  for side in (0,1):
   index+=1
   if index==107:job=(fam,setups[:],seed,side)
fam,setups,seed,side=job
print('job',fam,seed,side,setups,flush=True)
a=OriginalAI('ai/msdos1990',side,setups,seed*2+side+1)
e=Engine('build/ai-catalog/student-guard-v1-normal/engine');e.send('seed '+str(seed*2+(1-side)+1));e.send('new '+('red','blue')[1-side]);e.send('setup '+setups[1-side]);history=[]
try:
 for ply in range(1000):
  if not a.position.moves(ply%2):print('ended no moves',ply);break
  if ply%2==side:move=a.choose()
  else:move=tuple(map(parse_square,e.ask('go','move').split()))
  src,dst=move;target=a.position.cells[dst];attacker=a.position.cells[src][1]
  event=('battle '+square_name(src)+' '+square_name(dst)+' '+GLYPHS[attacker]+' '+GLYPHS[target[1]]) if target else 'moved '+square_name(src)+' '+square_name(dst)
  before=a.cpu.checkpoint();history.append(event)
  try:
   if target:a.observe(src,dst,attacker,target[1])
   else:a.observe(src,dst)
  except Exception:
   print('FAIL ply',ply,event,'prior',history[-8:],flush=True)
   Path('build/msdos-1990/repro107.json').write_text(json.dumps(dict(family=fam,seed=seed,side=side,setups=setups,ply=ply,history=history,before=before,after=a.cpu.checkpoint())))
   raise
  e.send(event)
  if target and target[1]==FLAG:print('ended flag',ply,event);break
finally:e.close()
